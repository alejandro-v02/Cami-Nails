import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import RosaDoradaNails from './page/RosaDoradaNails.jsx'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <RosaDoradaNails />
  </StrictMode>,
)